import javax.swing.*;
import java.util.*;
import java.awt.*;
/**
 *  the ball class holds most of the code for the game. The ball is one of the
 *  most important pieces because it can be anywhere on the screen so it is easiest
 *  to just handle all events based on the ball and it's location to keep the code
 *  consistent rather than try to update the blocks and the player bumper or walls
 *  or everything seperately.
 */
public class Ball extends PhysicsObject
{
    float w,h;
    public float normalizedAcc;
    boolean movingUp = false;
    boolean movingDown = false;
    boolean movingRight = false;
    boolean movingLeft = false;
    boolean noUp = false;
    boolean noDown = false;
    boolean noRight = false;
    boolean noLeft = false;
    CollisionBox hitBox;

    public Ball(float x, float y, float w, float h){
        super(x,y);
        this.w = w;
        this.h = h;
        hitBox = new CollisionBox(x,y,w,h);
        setNormalizedAcc(1);
    }

    /*
     * the normalizedAcc is the normalized acceleration per frame in pixels
     * this should stay one for this game and collison detection code, however
     * when I can make the collision detection more robust there are options
     * to use this to change speeds and not frame rate.
     */
    public void setNormalizedAcc(float pixels){
        normalizedAcc = pixels;
    }
    /*
     * this initalizes the ball moving up at the start of the game to give it
     * physics and from then it should never stop moving.
     */
    public void startMoving(){
        moveUp();
    }

    public void moveDown(){
        if(velocity.y<normalizedAcc && noDown == false){
            acceleration.setValues(0,normalizedAcc);
            velocity.addVector(acceleration);  
        }
        
        hitBox.updateCollision(location.x,location.y,w,h);
        noUp = false;
        hitBox.collideTop = false;
    }

    public void moveUp(){

        if(velocity.y>-normalizedAcc && noUp == false){
            acceleration.setValues(0,-normalizedAcc);
            velocity.addVector(acceleration);
        }
        
        hitBox.updateCollision(location.x,location.y,w,h);
        noDown = false;
        hitBox.collideBottom = false;
    }

    public void moveLeft(){
        if(velocity.x>-normalizedAcc && noLeft ==false){
            acceleration.setValues(-normalizedAcc,0);
            velocity.addVector(acceleration);
        }
        
        hitBox.updateCollision(location.x,location.y,w,h);
        noRight = false;
        hitBox.collideRight = false;
    }

    public void moveRight(){
        if(velocity.x<normalizedAcc && noRight == false){
            acceleration.setValues(normalizedAcc,0);
            velocity.addVector(acceleration);
        }
        
        hitBox.updateCollision(location.x,location.y,w,h);
        noLeft = false;
        hitBox.collideLeft = false;
    }
    /*
     * the bounce off the block will set the acceleration in the opposite
     * direction to make the ball bounce "like normal" because the collison 
     * will know if the hit was from any of the 4 sides and only update the
     * acceleration for the side that was hit from. EX: if the ball hits a block
     * on the left side of the block it will bounce off and start moving left
     * because the acceleration is inverted only for the left and right not
     * the top
     */
    public void bounceBlock(Block b){
        if((this.hitBox.collideTop || b.wall.collideBottom)||(this.hitBox.collideBottom || b.wall.collideTop)){
            acceleration.y = -velocity.y+(-velocity.y);
        }
        if((this.hitBox.collideRight || b.wall.collideLeft)||(this.hitBox.collideLeft || b.wall.collideRight)){
            acceleration.x = -velocity.x+(-velocity.x);
        }   
        velocity.addVector(acceleration);
        acceleration.setValues(0,0);
    }
    /*
     * the wall bounce functions in the same was as the block bounce. Wall bounce
     * with a float x input of 1 means the hit was on the sides of the walls
     * input of 2 means the ball hit the top of the screen. 
     */
    public void bounceWall(float x){
        if(x==1){
            acceleration.x = -velocity.x+(-velocity.x);
        }
        if(x==2){
            acceleration.y = -velocity.y+(-velocity.y);
        } 
        velocity.addVector(acceleration);
        hitBox.updateCollision(location.x,location.y,w,h);
        acceleration.setValues(0,0);
    }
    /*
     * the bumper bounce is intended to give the player conrol over the flow 
     * of the ball as it bounces across the screen. The player can move left or
     * right as the ball hits the bumper to either slow or speed up the ball
     * on the horizontal plane. To avoid a potential soft lock where the ball
     * moves in the same pattern and some blocks are inaccesable the random 
     * number is used to the arc of the ball bounce can change by smaller or
     * bigger amounts while also adding a bit of luck to keep the game fresh
     * with each playthrough
     */
    public void bounceBumper(Bumper p){
        Random r = new Random();
        if((p.velocity.x > 0) && (velocity.x <1)){
            float randSpeed = (r.nextInt(100-50)+50)*.01f;
            acceleration.x = randSpeed;
            //acceleration.x = 1;
            if(acceleration.x>1){
                acceleration.x =1;
            }
        }
        if((p.velocity.x<0) && (velocity.x >-1)){
            float randSpeed = (r.nextInt(100-50)+50)*-.01f;
            acceleration.x = randSpeed;
            //acceleration.x = -1;
            if(acceleration.x<-1){
                acceleration.x = -1;
            }
        }
        acceleration.y = -velocity.y+(-velocity.y);
        velocity.addVector(acceleration);
        hitBox.updateCollision(location.x,location.y,w,h);
        acceleration.setValues(0,0);
    }
}
