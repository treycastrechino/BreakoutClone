import javax.swing.*;
import java.util.*;
import java.awt.*;
/**
 * this is the block template that is used to create the rows of static blocks
 * at the top of the screen. very standard, x,y,w,h, collison box and is it alive?
 *
 */
public class Block
{
    CollisionBox wall;
    boolean alive = true;
    float x,y,width,height;
    public Block(float x,float y,float width, float height){
        this.x=x;
        this.y=y;
        this.width=width;
        this.height=height;
        wall = new CollisionBox(x,y,width,height);
    }
    /*
     * rather than try to get fancy and do a bunch of work updating an array
     * or using a list that can remove indexes as the get hit or all that
     * it is much more simple to just transport the block way off the screen
     * where the user will never be able to interact with it.
     */
    public void killBlock(){
        this.wall.x=900;
        this.x = 900;
        alive = false;
        wall.updateCollision(x,y,width,height);
    }
}
