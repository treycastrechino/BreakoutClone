import javax.swing.*;
import java.util.*;
import java.awt.*;
/**
 * the bumper is the player controlled rectangle at the bottom of the screen
 * it operates with left and right movements and is a standard physics object 
 * that responds to commands rather than operating on set physics like the ball
 * 
 */
public class Bumper extends PhysicsObject
{
    BumperControls m = new BumperControls(this);
    float w, h; 
    boolean movingLeft;
    boolean movingRight;
    boolean noRight;
    boolean noLeft;
    boolean stopped = false;
    float normalizedAcc;
    CollisionBox hitBox;
    public Bumper(float x, float y, float w, float h){
        super(x,y);
        this.w = w;
        this.h = h;
        velocity.setValues(0,0);
        hitBox = new CollisionBox(x,y,w,h);
        setNormalizedAcc(1);
    }
    /*
     * the move left and right functions are standard inputs to add acceleration
     * in either direction. They will also apply to up and down but aren't used
     * in this game.
     */
    public void moveLeft(){

        if(velocity.x>-normalizedAcc && noLeft == false){
            acceleration.setValues(-normalizedAcc,0);
            velocity.addVector(acceleration);
        }
        // if you just moved left it is impossible for you to be colliding with
        //something on the right
        noRight = false;
        hitBox.collideRight = false;
    }

    public void moveRight(){

        if(velocity.x<normalizedAcc && noRight == false){
            acceleration.setValues(normalizedAcc,0);
            velocity.addVector(acceleration);
        }
        noLeft = false;
        hitBox.collideLeft = false;
    }
    /*
     * the methods and keypress inputs work on press and release so this method
     * is designed to run when the left key is released to make the motions feel
     * more fluid.
     */
    public void stopLeft(){
        if(velocity.x<0){
            acceleration.setValues(normalizedAcc,0);
            velocity.addVector(acceleration);
        }
        movingLeft = false;
    }

    public void stopRight(){
        if(velocity.x>0){ 
            acceleration.setValues(-normalizedAcc,0);
            velocity.addVector(acceleration);
        }
        movingRight = false;
    }
    /*
     * these methods are to set flags when collison has happened to allow for 
     * the player to continue to move in all 3 other directions but not in 
     * the direction of the most recent collision
     */
    public void noRight(){
        if(!stopped){
            velocity.setValues(0,velocity.y);
            noRight = true;
        }
        else{
            return;
        }
    }

    public void noLeft(){
        if(!stopped){
            velocity.setValues(0,velocity.y);
            noLeft = true;
        }
        else{
            return;
        }
    }

    public void setNormalizedAcc(float pixels){
        normalizedAcc = pixels;
    }
}
