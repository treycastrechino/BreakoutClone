import java.util.*;
import java.awt.*;
import java.awt.event.*;
/**
 * bumper controls is a specific name for an import that will create any controls
 * input from the user on a keyboard. It can easily be modified to run methods
 * related to any button.
 */
public class BumperControls implements KeyListener
{
    Bumper o;
    public BumperControls(Bumper o){
        this.o = o;
    }

    public void keyPressed(KeyEvent e){
        int keyCode = e.getKeyCode();

        if(keyCode == KeyEvent.VK_DOWN){

        }

        if(keyCode == KeyEvent.VK_UP){

        }

        if(keyCode == KeyEvent.VK_LEFT){  
            o.movingLeft = true;
        }

        if(keyCode == KeyEvent.VK_RIGHT){
            o.movingRight = true; 
        }

    }
    //runs when key released
    public void keyReleased(KeyEvent e){
        int keyCode = e.getKeyCode();
        if(keyCode == KeyEvent.VK_DOWN){
           
        }
        if(keyCode == KeyEvent.VK_UP){
          
        }
        if(keyCode == KeyEvent.VK_LEFT){
           //o.movingLeft = false;
           o.stopLeft();
        }
        if(keyCode == KeyEvent.VK_RIGHT){
           //o.movingRight = false;
           o.stopRight();
        }
    }
    // detects key pressed and released quickly
    public void keyTyped(KeyEvent e){

    }

}
