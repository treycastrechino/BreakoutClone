import javax.swing.*;
import java.util.*;
import java.awt.*;
/**
 * this class is a template for a collision box that can detect collisions
 * from up, down, left or right. Important notes are that this collison detection
 * is pixel perfect but only when speeds are at no more than one pixel per frame
 * to change the frame rate is how you adjust speeds or the object can end up
 * inside the collison box in one frame and collison detection will go to crap.
 * another important note is the collision is designed to be checked from the outside in
 * if you needed to create static collision that an object was inside of
 * (like an indoor wall) you would need to use 4 boxes, one for each side only
 * detecting that wall. Or create a new class to hold inside out collison.
 */
public class CollisionBox
{
    float x,y,width,height;
    JVector topRight,topLeft,bottomRight,bottomLeft;
    public boolean collideRight = false;
    public boolean collideLeft = false;
    public boolean collideBottom = false;
    public boolean collideTop = false;
    public CollisionBox(float x,float y,float width,float height){
        this.x=x;
        this.y=y;
        this.width=width;
        this.height=height;
        topRight= new JVector(this.x+width,this.y);
        topLeft= new JVector(this.x,this.y);
        bottomLeft= new JVector(this.x,this.y+height);
        bottomRight= new JVector(this.x+width,this.y+height);
    }

    public boolean intersects(CollisionBox j){
        if((this.bottomRight.x>=j.topLeft.x)&&(this.bottomRight.x<=j.topRight.x)&&(this.bottomRight.y>=j.topLeft.y)&&(this.bottomRight.y<=j.bottomLeft.y)){
            if(this.bottomRight.x==j.topLeft.x){
                collideRight = true;
            }
            if(this.bottomRight.y==j.topLeft.y){
                collideBottom = true;
            }
            if(this.bottomRight.x==j.topLeft.x+1){
                collideRight = true;
            }
            if(this.bottomRight.y==j.topLeft.y+1){
                collideBottom = true;
            }
            return true;
        }
        else{
            collideRight = false;
            collideBottom = false;
        }
        if((this.bottomLeft.x>=j.topLeft.x)&&(this.bottomLeft.x<=j.topRight.x)&&(this.bottomLeft.y>=j.topLeft.y)&&(this.bottomLeft.y<=j.bottomLeft.y)){
            if(this.bottomLeft.x==j.topRight.x){
                collideLeft = true;
            }
            if(this.bottomLeft.y==j.topRight.y){
                collideBottom = true;
            }
            if(this.bottomLeft.x==j.topRight.x-1){
                collideLeft = true;
            }
            if(this.bottomLeft.y==j.topRight.y+1){
                collideBottom = true;
            }
            return true;
        }
        else{
            collideLeft = false;
            collideBottom = false;
        }
        if((this.topLeft.x>=j.topLeft.x)&&(this.topLeft.x<=j.topRight.x)&&(this.topLeft.y>=j.topLeft.y)&&(this.topLeft.y<=j.bottomLeft.y)){
            if(this.topLeft.x==j.bottomRight.x){
                collideLeft = true;
            }
            if(this.topLeft.y==j.bottomRight.y){
                collideTop = true;
            }
            if(this.topLeft.x==j.bottomRight.x-1){
                collideLeft = true;
            }
            if(this.topLeft.y==j.bottomRight.y-1){
                collideTop = true;
            }
            return true;
        }
        else{
            collideLeft = false;
            collideTop = false;
        }
        if((this.topRight.x>=j.topLeft.x)&&(this.topRight.x<=j.topRight.x)&&(this.topRight.y>=j.topLeft.y)&&(this.topRight.y<=j.bottomLeft.y)){
            if(this.topRight.x==j.bottomLeft.x){
                collideRight = true;
            }
            if(this.topRight.y==j.bottomLeft.y){
                collideTop = true;
            }
            if(this.topRight.x==j.bottomLeft.x+1){
                collideRight = true;
            }
            if(this.topRight.y==j.bottomLeft.y-1){
                collideTop = true;
            }
            return true;
        }
        else{
            collideRight = false;
            collideTop = false;
        }
        return false;
    }
    /*
     * this method can be ran whenever the game updates or whenever a 
     * change in location has occured for the collision box.
     */
    public void updateCollision(float x,float y,float w,float h){
        this.x = x;
        this.y = y;
        this.width = w;
        this.height = h;
        topRight.setValues(this.x+width,this.y);
        topLeft.setValues(this.x,this.y);
        bottomLeft.setValues(this.x,this.y+height);
        bottomRight.setValues(this.x+height,this.y+width);
    }
}
