import javax.swing.*;
import java.util.*;
import java.awt.*;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

/**
 * this class will run the game and keep track of all the pieces as well as 
 * do the painting to the screen.
 */
public class Game extends Canvas
{
    JFrame frame;
    Block[][] blocks = new Block[4][10];
    Bumper player;
    Ball b;
    Color[] colors = new Color[4];
    BufferedImage bf;
    CollisionBox bounds;
    Graphics offScreenG;
    // these may not all be implemented. I was trying to stop screen flicker
    BufferedImage offScreenI;
    BufferedImage offScreenI2;
    BufferedImage offScreenI3;
    public Game(){
        setSize(412,250);
        bounds = new CollisionBox(0,0,getWidth(),getHeight());
        player = new Bumper((getWidth()/2)-25,getHeight()-20,50,10);
        initializeBlocks();
        b = new Ball((getWidth()/2)-5,getHeight()-60,10,10);
        colors[0] = Color.red;
        colors[1] = Color.green;
        colors[2] = Color.blue;
        colors[3] = Color.yellow;
        setBackground(Color.black);
        frame = new JFrame("Breakout");
        frame.getContentPane().add(this);
        frame.addKeyListener(player.m);
        frame.setFocusable(true);
        frame.setFocusTraversalKeysEnabled(true);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    public static void main(String[] args) throws InterruptedException{
        Game game = new Game();
        game.b.startMoving();
        //this loop keeps the game running and the thread.sleep controls
        //the frame rate. so if you wanted the ball to move faster you could
        //decrease the number.
        while(true){
            game.update();
            Thread.sleep(5);
        }
    }
    /*
     * every frame this method is ran and will test all the collisons and
     * redraw or update physics as needed
     */
    public void update(){

        repaint();
        if(player.movingRight){
            player.moveRight();
        }
        if(player.movingLeft){
            player.moveLeft();
        }

        testBallBlockCollision();
        testBallWallCollision();
        testBallPlayerCollision();
        testPlayerWallCollision();
        player.location.addVector(player.velocity);
        player.hitBox.updateCollision(player.location.x,player.location.y,player.w,player.h);
        b.location.addVector(b.velocity);
        b.hitBox.updateCollision(b.location.x,b.location.y,b.w,b.h);
    }
    /*
     * this method runs through each block in the array to test for collisons
     */
    public void testBallBlockCollision(){
        for(int i = 0; i<4; i++){

            for(int j = 0; j<10; j++){

                if(b.hitBox.intersects(blocks[i][j].wall)){
                    blocks[i][j].killBlock();
                    b.bounceBlock(blocks[i][j]);
                    break;
                }

            }

        }
    }
    
    public void testPlayerWallCollision(){
        if(player.location.x <=0){
            player.stopLeft();
        }

        if((player.location.x+50)>=getWidth()){
            player.stopRight();
        } 
    }

    public void testBallPlayerCollision(){

        if(b.hitBox.intersects(player.hitBox)){
            b.bounceBumper(player);
        }
    }

    public void testBallWallCollision(){

        if(((b.location.x+10)>=getWidth()) || (b.location.x <=0)){
            b.bounceWall(1);
        }
        if(b.location.y <= 0){
            b.bounceWall(2);
        } 

    }
    /*
     * initalizes the blocks with offsets to make 4 rows with small spaces
     * between
     */
    public void initializeBlocks(){
        int xoffset = 2;
        int yoffset = 11;
        for(int i = 0; i<4; i++){
            xoffset = 2;
            for(int j = 0; j<10; j++){
                blocks[i][j] = new Block(xoffset,yoffset,40,10);
                xoffset = xoffset+41;

            }

            yoffset = yoffset+11;
        }
    }
    /*
     * this method needs work but it will cycle through the 4 colors for the
     * blocks and draw the bumper and ball where they are suppposed to be
     * for now. I was able to stop object flickering with the double buffer
     * thing I tried. But wasn't able to stop the screen flicker. It still looks
     * a lot better.
     */
    public void paint(Graphics g){ 
        offScreenI = new BufferedImage(this.getWidth(),this.getHeight(),BufferedImage.TYPE_INT_RGB);
        offScreenG = offScreenI.getGraphics();
        offScreenG.setColor(Color.white);
        offScreenG.fillRect((int)b.location.x,(int)b.location.y,(int)b.w,(int)b.h);
        for(int i = 0; i<4; i++){

            for(int j = 0; j<10; j++){
                offScreenG.setColor(colors[i]);
                if(blocks[i][j].alive= true){
                    offScreenG.fillRect((int)blocks[i][j].x,(int)blocks[i][j].y,(int)blocks[i][j].width,(int)blocks[i][j].height);
                }
            }
        }

        offScreenG.setColor(Color.white);
        offScreenG.fillRect((int)player.location.x,(int)player.location.y,(int)player.w,(int)player.h);
        offScreenI2 = offScreenI;
        g.drawImage(offScreenI2,0,0,this);
    }
}
