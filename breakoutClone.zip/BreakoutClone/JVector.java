import javax.swing.*;
import java.util.*;
import java.awt.*;
/**
 * this is a template class for a 2D vector object with an x and y.
 * it can be easily modified to support a z axis.
 */
public class JVector
{
    public float x;
    public float y;
    public float magnitude;

    public JVector(float x,float y){
        this.x = x;
        this.y = y;
        updateMagnitude();
    }

    public void setValues(float x,float y){
        this.x = x;
        this.y = y;
    }

    public void addVector(JVector j){
        this.x = this.x + j.x;
        this.y = this.y + j.y;
    }
    // use this to find things like velocity between two pofloats.
    // like new pofloat minus old pofloat == pofloat velocity, pretty much
    // what changed
    public void subtractVector(JVector j){
        this.x = this.x - j.x;
        this.y = this.y - j.y;
    }

    public void multiplyVector(float scale){
        this.x = this.x*scale;
        this.y = this.y*scale;
    }

    public void updateMagnitude(){
        double power = (this.x*this.x)+(this.y*this.y);
        this.magnitude = (float)Math.sqrt(power);
    }

    public float returnMagnitude(){
        return this.magnitude;
    }
}
