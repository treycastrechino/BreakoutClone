import javax.swing.*;
import java.util.*;
import java.awt.*;
/**
 * this is the template class for any object that can move.
 */
public class PhysicsObject
{
    CollisionBox hitBox;
    public JVector location = new JVector(0,0);
    public JVector velocity = new JVector(0,0);
    public JVector acceleration = new JVector(0,0);
    public PhysicsObject(float x,float y){
        this.location.x = x;
        this.location.y = y;
    }

    public void moveDown(){

    }

    public void moveUp(){

    }

    public void moveLeft(){

    }

    public void moveRight(){

    }
}
